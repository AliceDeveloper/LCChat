//
//  LCChatVC.h
//  LCRACMVVMRouter
//
//  Created by 李春 on 2018/12/24.
//  Copyright © 2018 LCRACMVVMRouter. All rights reserved.
//

#import "LCBaseVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface LCChatVC : LCBaseVC

@end

NS_ASSUME_NONNULL_END
