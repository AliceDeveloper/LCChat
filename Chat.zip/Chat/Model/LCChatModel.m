//
//  LCChatModel.m
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/17.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatModel.h"

@implementation LCChatModel

// 文本测试数据
+ (NSArray *)textDemo {
    
    NSMutableArray *array = [NSMutableArray array];
    
    LCChatModel *model = [[LCChatModel alloc] init];
    model.isSelf = NO;
    model.msgType = LCChatMsgType_Text;
    model.timeMsg = @"2018-12-12 12:12";
    model.headUrl = @"Chat_head";
    model.textMsg = @"我是长文本我是长文本我是长文本我是长文本我是长文本我是长文本我是长文本我是长文本我是长文本我是长文本我是长文本";
    [array addObject:model];
    
    model = [[LCChatModel alloc] init];
    model.isSelf = YES;
    model.msgType = LCChatMsgType_Text;
    model.timeMsg = @"2018-12-12 12:12";
    model.headUrl = @"Chat_head";
    model.textMsg = @"我是短文本";
    [array addObject:model];
    
    return array;
}

// 图片测试数据
+ (NSArray *)imgDemo {
    
    NSMutableArray *array = [NSMutableArray array];
    
    LCChatModel *model = [[LCChatModel alloc] init];
    model.isSelf = NO;
    model.msgType = LCChatMsgType_Image;
    model.timeMsg = @"2018-12-12 12:12";
    model.headUrl = @"Chat_head";
    model.imgUrl = @"Chat_image";
    [array addObject:model];
    
    model = [[LCChatModel alloc] init];
    model.isSelf = YES;
    model.msgType = LCChatMsgType_Image;
    model.timeMsg = @"2018-12-12 12:12";
    model.headUrl = @"Chat_head";
    model.imgUrl = @"Chat_image";
    [array addObject:model];
    
    model = [[LCChatModel alloc] init];
    model.isSelf = NO;
    model.msgType = LCChatMsgType_Image;
    model.timeMsg = @"2018-12-12 12:12";
    model.headUrl = @"Chat_head";
    model.imgUrl = @"Chat_H";
    [array addObject:model];
    
    model = [[LCChatModel alloc] init];
    model.isSelf = YES;
    model.msgType = LCChatMsgType_Image;
    model.timeMsg = @"2018-12-12 12:12";
    model.headUrl = @"Chat_head";
    model.imgUrl = @"Chat_V";
    [array addObject:model];
    
    return array;
}

// 视频测试数据
+ (NSArray *)videoDemo {
    
    NSMutableArray *array = [NSMutableArray array];
    
    LCChatModel *model = [[LCChatModel alloc] init];
    model.isSelf = NO;
    model.msgType = LCChatMsgType_Video;
    model.timeMsg = @"2018-12-12 12:12";
    model.headUrl = @"Chat_head";
    model.videoUrl = @"";
    model.videoPlaceUrl = @"Chat_image";
    model.videoLen = @"00:00:00";
    [array addObject:model];
    
    model = [[LCChatModel alloc] init];
    model.isSelf = YES;
    model.msgType = LCChatMsgType_Video;
    model.timeMsg = @"2018-12-12 12:12";
    model.headUrl = @"Chat_head";
    model.videoUrl = @"";
    model.videoPlaceUrl = @"Chat_image";
    model.videoLen = @"00:00:00";
    [array addObject:model];
    
    return array;
}

// 语音测试数据
+ (NSArray *)voiceDemo {
    
    NSMutableArray *array = [NSMutableArray array];
    
    LCChatModel *model = [[LCChatModel alloc] init];
    model.isSelf = NO;
    model.msgType = LCChatMsgType_Voice;
    model.timeMsg = @"2018-12-12 12:12";
    model.headUrl = @"Chat_head";
    model.voiceUrl = @"";
    model.voiceLen = @"8";
    [array addObject:model];
    
    model = [[LCChatModel alloc] init];
    model.isSelf = YES;
    model.msgType = LCChatMsgType_Voice;
    model.timeMsg = @"2018-12-12 12:12";
    model.headUrl = @"Chat_head";
    model.voiceUrl = @"";
    model.voiceLen = @"3";
    [array addObject:model];
    
    return array;
}

@end
