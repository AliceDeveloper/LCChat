//
//  LCChatModel.h
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/17.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LCChatMsgType) {
    LCChatMsgType_Text,         // 文本
    LCChatMsgType_Image,        // 图片
    LCChatMsgType_Voice,        // 语音
    LCChatMsgType_Video,        // 视频
};

typedef NS_ENUM(NSUInteger, LCChatMsgStatus) {
    LCChatMsgStatus_Send,       // 已发送
    LCChatMsgStatus_Sending,    // 发送中
    LCChatMsgStatus_Unsend,     // 发送失败
    LCChatMsgStatus_Read,       // 已读
    LCChatMsgStatus_Unread,     // 未读
};

@interface LCChatModel : NSObject

// 是否是自己发送的消息
@property (nonatomic, assign) BOOL isSelf;
// 消息类型：文本、图片、语音、视频
@property (nonatomic, assign) LCChatMsgType msgType;
// 消息状态：已发送、发送中、发送失败、已读、未读
@property (nonatomic, assign) LCChatMsgStatus msgStatus;
// 时间
@property (nonatomic, strong) NSString *timeMsg;
// 头像
@property (nonatomic, strong) NSString *headUrl;
// 文本消息
@property (nonatomic, strong) NSString *textMsg;
// 图片路径
@property (nonatomic, strong) NSString *imgUrl;
// 语音路径
@property (nonatomic, strong) NSString *voiceUrl;
// 语音时长，单位秒
@property (nonatomic, strong) NSString *voiceLen;
// 视频路径
@property (nonatomic, strong) NSString *videoUrl;
// 视频占位图片
@property (nonatomic, strong) NSString *videoPlaceUrl;
// 视频时长
@property (nonatomic, strong) NSString *videoLen;

// 文本测试数据
+ (NSArray *)textDemo;
// 图片测试数据
+ (NSArray *)imgDemo;
// 视频测试数据
+ (NSArray *)videoDemo;
// 语音测试数据
+ (NSArray *)voiceDemo;

@end

NS_ASSUME_NONNULL_END
