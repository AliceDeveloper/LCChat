//
//  LCChatPane.m
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/9.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatPane.h"
#import "LCChatPaneSymbolCell.h"
#import "LCChatPaneAddCell.h"

@interface LCChatPane () <UICollectionViewDataSource, UICollectionViewDelegate>

@property (nonatomic, strong) UIView *symbolView;
@property (nonatomic, strong) UICollectionView *symbolCol;
@property (nonatomic, strong) NSArray *symbolList;

@property (nonatomic, strong) UIView *addView;
@property (nonatomic, strong) UICollectionView *addCol;
@property (nonatomic, strong) NSArray *addList;

@end

@implementation LCChatPane

- (void)setType:(LCChatPaneType)type {
    
    _type = type;
    if (_type == LCChatPaneType_Symbol) {
        self.symbolView.hidden = NO;
        self.addView.hidden = YES;
        [self symbolCol];
    }
    if (_type == LCChatPaneType_Add) {
        self.addView.hidden = NO;
        self.symbolView.hidden = YES;
        [self addCol];
    }
}

#pragma mark - <UICollectionViewDataSource, UICollectionViewDelegate>

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    if (self.type == LCChatPaneType_Symbol) {
        return self.symbolList.count;
    }
    if (self.type == LCChatPaneType_Add) {
        return self.addList.count;
    }
    
    return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (self.type == LCChatPaneType_Symbol) {
        LCChatPaneSymbolCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"LCChatPaneSymbolCell" forIndexPath:indexPath];
        cell.symbolIv.image = [UIImage imageNamed:(self.symbolList[indexPath.row])[@"icon"]];
        return cell;
    }
    if (self.type == LCChatPaneType_Add) {
        LCChatPaneAddCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"LCChatPaneAddCell" forIndexPath:indexPath];
        cell.iconIv.image = [UIImage imageNamed:(self.addList[indexPath.row])[@"icon"]];
        cell.titleL.text = (self.addList[indexPath.row])[@"name"];
        return cell;
    }
    
    return nil;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (self.type == LCChatPaneType_Symbol) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(symbolItemClicked:name:)]) {
            [self.delegate symbolItemClicked:indexPath.row name:(self.symbolList[indexPath.row])[@"name"]];
        }
    }
    if (self.type == LCChatPaneType_Add) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(addItemClicked:name:)]) {
            [self.delegate addItemClicked:indexPath.row name:(self.addList[indexPath.row])[@"name"]];
        }
    }
}

#pragma mark - SET/GET

- (UIView *)symbolView {
    
    if (_symbolView == nil) {
        _symbolView = [[UIView alloc] initWithFrame:self.bounds];
        _symbolView.backgroundColor = [UIColor whiteColor];
        [self addSubview:_symbolView];
    }
    
    return _symbolView;
}

- (UIView *)addView {
    
    if (_addView == nil) {
        _addView = [[UIView alloc] initWithFrame:self.bounds];
        _addView.backgroundColor = [UIColor whiteColor];
        [self addSubview:_addView];
    }
    
    return _addView;
}

- (UICollectionView *)symbolCol {
    
    if (_symbolCol == nil) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        layout.minimumLineSpacing = 0;
        layout.minimumInteritemSpacing = 0;
        layout.sectionInset = UIEdgeInsetsZero;
        CGFloat itemWidth =  self.symbolView.bounds.size.width / 16;
        CGFloat itemHeight = self.symbolView.bounds.size.height / 3;
        layout.itemSize = CGSizeMake(itemWidth, itemHeight);
        _symbolCol = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _symbolCol.backgroundColor = [UIColor whiteColor];
        _symbolCol.delegate = self;
        _symbolCol.dataSource = self;
        _symbolCol.showsVerticalScrollIndicator = NO;
        _symbolCol.showsHorizontalScrollIndicator = NO;
        _symbolCol.pagingEnabled = YES;
        [self.symbolView addSubview:_symbolCol];
        [_symbolCol mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.bottom.equalTo(self.symbolView);
        }];
        [_symbolCol registerClass:[LCChatPaneSymbolCell class]
       forCellWithReuseIdentifier:@"LCChatPaneSymbolCell"];
    }
    
    return _symbolCol;
}

- (UICollectionView *)addCol {
    
    if (_addCol == nil) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        layout.minimumLineSpacing = 0;
        layout.minimumInteritemSpacing = 0;
        layout.sectionInset = UIEdgeInsetsZero;
        CGFloat itemWidth =  self.addView.bounds.size.width / 8;
        CGFloat itemHeight = self.addView.bounds.size.height;
        layout.itemSize = CGSizeMake(itemWidth, itemHeight);
        _addCol = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _addCol.backgroundColor = [UIColor whiteColor];
        _addCol.delegate = self;
        _addCol.dataSource = self;
        _addCol.showsVerticalScrollIndicator = NO;
        _addCol.showsHorizontalScrollIndicator = NO;
        _addCol.pagingEnabled = YES;
        [self.addView addSubview:_addCol];
        [_addCol mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.bottom.equalTo(self.addView);
        }];
        [_addCol registerClass:[LCChatPaneAddCell class]
    forCellWithReuseIdentifier:@"LCChatPaneAddCell"];
    }
    
    return _addCol;
}

- (NSArray *)symbolList {
    
    if (_symbolList == nil) {
        _symbolList = @[@{@"icon" : @"Chat_Sending", @"name" : @""},
                        @{@"icon" : @"Chat_Sending", @"name" : @""},
                        @{@"icon" : @"Chat_Sending", @"name" : @""}];
    }
    
    return _symbolList;
}

- (NSArray *)addList {
    
    if (_addList == nil) {
        _addList = @[@{@"icon" : @"", @"name" : @"图片"},
                     @{@"icon" : @"", @"name" : @"视频"}];
    }
    
    return _addList;
}

@end
