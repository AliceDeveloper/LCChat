//
//  LCChatPaneAddCell.m
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/30.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatPaneAddCell.h"

static CGFloat space = 8.0f;

@implementation LCChatPaneAddCell

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self iconIv];
    [self titleL];
}

#pragma mark - SET/GET

- (UIImageView *)iconIv {
    
    if (_iconIv == nil) {
        _iconIv = [[UIImageView alloc] init];
        _iconIv.contentMode = UIViewContentModeScaleAspectFill;
        _iconIv.layer.masksToBounds = YES;
        [self addSubview:_iconIv];
        [_iconIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(space);
            make.right.mas_equalTo(-space);
            make.bottom.equalTo(self.titleL.mas_top).offset(-space);
        }];
    }
    
    return _iconIv;
}

- (UILabel *)titleL {
    
    if (_titleL == nil) {
        _titleL = [[UILabel alloc] init];
        _titleL.textAlignment = NSTextAlignmentCenter;
        _titleL.textColor = [UIColor blackColor];
        _titleL.font = [UIFont systemFontOfSize:15];
        [self addSubview:_titleL];
        [_titleL mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(20);
            make.left.mas_equalTo(space);
            make.right.bottom.mas_equalTo(-space);
        }];
    }
    
    return _titleL;
}

@end
