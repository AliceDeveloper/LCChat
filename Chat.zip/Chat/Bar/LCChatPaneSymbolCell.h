//
//  LCChatPaneSymbolCell.h
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/30.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LCChatPaneSymbolCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *symbolIv;

@end

NS_ASSUME_NONNULL_END
