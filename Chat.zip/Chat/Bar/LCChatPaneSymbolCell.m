//
//  LCChatPaneSymbolCell.m
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/30.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatPaneSymbolCell.h"

static CGFloat space = 8.0f;

@implementation LCChatPaneSymbolCell

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self symbolIv];
}

#pragma mark - SET/GET

- (UIImageView *)symbolIv {
    
    if (_symbolIv == nil) {
        _symbolIv = [[UIImageView alloc] init];
        _symbolIv.contentMode = UIViewContentModeCenter;
        _symbolIv.layer.masksToBounds = YES;
        [self addSubview:_symbolIv];
        [_symbolIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(space);
            make.right.bottom.mas_equalTo(-space);
        }];
    }
    
    return _symbolIv;
}

@end
