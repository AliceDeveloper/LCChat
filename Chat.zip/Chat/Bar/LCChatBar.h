//
//  LCChatBar.h
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/9.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+Chat.h"
#import "LCChatPane.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LCChatBarType) {
    LCChatBarType_Default,  // 默认
    LCChatBarType_Text,     // 文本
    LCChatBarType_Voice,    // 语音
    LCChatBarType_Symbol,   // 表情
    LCChatBarType_Add,      // 添加
};

@protocol LCChatBarDelegate <NSObject>

// 更新显示
- (void)refreshUI;
// 发送文本信息
- (void)sendTextMsg:(NSString *)msg;
// 发送图片信息
- (void)sendImageMsg:(UIImage *)img;
// 发送视频信息
- (void)sendVideoMsg:(NSString *)videoPath;
// 发送语音信息
- (void)sendVoiceMsg:(NSString *)voicePath;

@end

@interface LCChatBar : UIView <UITextViewDelegate, LCChatPaneDelegate>

// 初始化方法
- (instancetype)initWithOwner:(UIViewController *)owner;
// 代理
@property (nonatomic, weak) id <LCChatBarDelegate> delegate;
// 当前显示类型
@property (nonatomic, assign) LCChatBarType type;
// 表情或自定义功能
@property (nonatomic, strong) LCChatPane *pane;

@end

NS_ASSUME_NONNULL_END
