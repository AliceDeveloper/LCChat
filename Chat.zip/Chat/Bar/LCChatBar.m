//
//  LCChatBar.m
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/9.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatBar.h"

// 背景颜色或线条颜色
#define LCChatBgColor [UIColor colorWithRed:234 / 255.0 green:234 / 255.0 blue:234 / 255.0 alpha:1]
#define LCChatScreenW           [UIScreen mainScreen].bounds.size.width
#define LCChatScreenH           [UIScreen mainScreen].bounds.size.height
#define LCChatSpaceH            8   // 水平间隙
#define LCChatSpaceV            10  // 垂直间隙
#define LCChatBarHeight         50  // 输入部分高度
#define LCChatBarBtn            30  // 输入部分按钮宽高
#define LCChatInput             34  // 表单默认高度
#define LCChatInputMax          84  // 表单最大高度
#define LCChatInputSpaceV       8   // 表单上下间隙

@interface LCChatBar ()

// 控件
@property (nonatomic, strong) UIButton *currentBtn;
@property (nonatomic, strong) UIButton *voice;
@property (nonatomic, strong) UIButton *record;
@property (nonatomic, strong) UITextView *input;
@property (nonatomic, strong) UIButton *symbol;
@property (nonatomic, strong) UIButton *add;
// 传入控制器、状态栏加导航栏的高度、表单的高度、键盘高度
@property (nonatomic, strong) UIViewController *owner;
@property (nonatomic, assign) CGFloat top;
@property (nonatomic, assign) CGFloat inputHeight;
@property (nonatomic, assign) CGFloat kbHeight;

@end

@implementation LCChatBar

- (void)dealloc {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

// 获取屏幕安全区域
- (UIEdgeInsets)safeArea {
    
    // 对于SB和Xib页面没有验证，可能存在误差
    if (@available(iOS 11.0, *)) {
        return [[UIApplication sharedApplication].windows firstObject].safeAreaInsets;
    } else {
        return UIEdgeInsetsZero;
    }
}

// 初始化方法
- (instancetype)initWithOwner:(UIViewController *)owner {
    self = [super init];
    
    if (self) {
        self.backgroundColor = LCChatBgColor;
        self.owner = owner;
        self.top = [UIApplication sharedApplication].statusBarFrame.size.height
        + self.owner.navigationController.navigationBar.frame.size.height;
        self.frame = CGRectMake(0, LCChatScreenH - self.top - [self safeArea].bottom - LCChatBarHeight, LCChatScreenW, LCChatBarHeight);
        // 初始化显示类型
        self.type = LCChatBarType_Default;
        // 初始化输入框的高度
        self.inputHeight = LCChatInput;
        // 键盘高度
        self.kbHeight = 0;
        // 初始化控件
        [self voice];
        [self record];
        [self input];
        [self symbol];
        [self add];
        // 键盘通知
        [[NSNotificationCenter defaultCenter]
         addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter]
         addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    }
    
    return self;
}

- (void)keyboardWillShow:(NSNotification *)notification {
    
    NSDictionary *useInfo = [notification userInfo];
    NSValue *value = [useInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    // 设置键盘高度
    self.kbHeight = [value CGRectValue].size.height - [self safeArea].bottom;
    // 所有按钮都要复位
    self.currentBtn.selected = NO;
    self.type = LCChatBarType_Text;
    // 更新显示
    [self updateUI];
}

- (void)keyboardWillHide:(NSNotification *)notification {
    
    // 重置键盘高度
    self.kbHeight = 0;
    // 更新显示
    [self updateUI];
}

// 关闭显示
- (void)dismissChatBar {
    
    // 所有按钮都要复位
    self.currentBtn.selected = NO;
    self.type = LCChatBarType_Default;
    // 更新显示
    [self updateUI];
}

#pragma mark - 按钮事件处理

- (void)buttonHandler:(UIButton *)sender {
    
    // 复原当前按钮的状态
    self.currentBtn.selected = NO;
    // 设置新按下的按钮为当前按钮
    self.currentBtn = sender;
    switch (self.type) {
        case LCChatBarType_Default: {
            if (sender == self.voice) {
                self.type = LCChatBarType_Voice;
            }
            if (sender == self.symbol) {
                self.type = LCChatBarType_Symbol;
            }
            if (sender == self.add) {
                self.type = LCChatBarType_Add;
            }
            break;
        }
        case LCChatBarType_Text: {
            if (sender == self.voice) {
                self.type = LCChatBarType_Voice;
            }
            if (sender == self.symbol) {
                self.type = LCChatBarType_Symbol;
            }
            if (sender == self.add) {
                self.type = LCChatBarType_Add;
            }
            break;
        }
        case LCChatBarType_Voice: {
            if (sender == self.voice) {
                self.type = LCChatBarType_Text;
            }
            if (sender == self.symbol) {
                self.type = LCChatBarType_Symbol;
            }
            if (sender == self.add) {
                self.type = LCChatBarType_Add;
            }
            break;
        }
        case LCChatBarType_Symbol: {
            if (sender == self.voice) {
                self.type = LCChatBarType_Voice;
            }
            if (sender == self.symbol) {
                self.type = LCChatBarType_Text;
            }
            if (sender == self.add) {
                self.type = LCChatBarType_Add;
            }
            break;
        }
        case LCChatBarType_Add: {
            if (sender == self.voice) {
                self.type = LCChatBarType_Voice;
            }
            if (sender == self.symbol) {
                self.type = LCChatBarType_Symbol;
            }
            if (sender == self.add) {
                self.type = LCChatBarType_Text;
            }
            break;
        }
        default:
            break;
    }
    
    // 根据类型设置选中按钮
    switch (self.type) {
        case LCChatBarType_Default:
            break;
        case LCChatBarType_Text:
            break;
        case LCChatBarType_Voice:
            self.voice.selected = YES;
            break;
        case LCChatBarType_Symbol:
            self.symbol.selected = YES;
            break;
        case LCChatBarType_Add:
            self.add.selected = YES;
            break;
        default:
            break;
    }
    
    // 更新显示
    [self updateUI];
}

// 更新显示
- (void)updateUI {
    
    // 根据类型判断显示表情视图
    if (self.type == LCChatBarType_Symbol) {
        self.pane.type = LCChatPaneType_Symbol;
    }
    // 根据类型判断显示自定义功能视图
    if (self.type == LCChatBarType_Add) {
        self.pane.type = LCChatPaneType_Add;
    }
    [UIView animateWithDuration:0.25 animations:^{
        // 更新输入栏的位置、更新表情或者自定义功能视图的位置
        if (self.type == LCChatBarType_Symbol || self.type == LCChatBarType_Add) {
            self.y = LCChatScreenH - self.top - (self.inputHeight + 2 * LCChatInputSpaceV + LCChatPaneHeight + [self safeArea].bottom);
            self.pane.y = self.bottom;
        } else {
            self.y = LCChatScreenH - self.top - (self.inputHeight + 2 * LCChatInputSpaceV + [self safeArea].bottom);
            self.pane.y = LCChatScreenH;
        }
        // 语音类型需要隐藏输入框
        self.input.hidden = self.type == LCChatBarType_Voice ? YES : NO;
        // 文本类型需要显示键盘，其他类型不显示键盘
        if (self.type == LCChatBarType_Text) {
            self.y -= self.kbHeight;
            [self.input becomeFirstResponder];
        } else {
            [self.input resignFirstResponder];
        }
    } completion:^(BOOL finished) {
        [self layoutIfNeeded];
        if (self.delegate && [self.delegate respondsToSelector:@selector(refreshUI)]) {
            [self.delegate refreshUI];
        }
    }];
}

#pragma mark - <UITextViewDelegate>

// 拦截发送按钮
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
    if ([text isEqualToString:@"\n"]) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(sendTextMsg:)]) {
            [self.delegate sendTextMsg:textView.text];
        }
        textView.text = @"";
        return NO;
    }
    
    return YES;
}

// 监听输入框的操作 输入框高度动态变化
- (void)textViewDidChange:(UITextView *)textView {
    
}

#pragma mark - 录音

- (void)startRecord:(UIButton *)sender {
    
    NSLog(@"开始录音");
}

- (void)endRecord:(UIButton *)sender {
    
    NSLog(@"结束录音");
    if (self.delegate && [self.delegate respondsToSelector:@selector(sendVoiceMsg:)]) {
        [self.delegate sendVoiceMsg:@""];
    }
}

- (void)cancelRecord:(UIButton *)sender {
    
    NSLog(@"取消录音");
}

- (void)remindDragExit:(UIButton *)sender {
    
    NSLog(@"拖出");
}

- (void)remindDragEnter:(UIButton *)sender {
    
    NSLog(@"拖入");
}

#pragma mark - <LCChatPaneDelegate>

- (void)symbolItemClicked:(NSUInteger)index name:(NSString *)name {
    
    [self dismissChatBar];
}

- (void)addItemClicked:(NSUInteger)index name:(NSString *)name {
    
    [self dismissChatBar];
    if ([name isEqualToString:@"图片"]) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(sendImageMsg:)]) {
            [self.delegate sendImageMsg:[UIImage imageNamed:@""]];
        }
    }
    if ([name isEqualToString:@"视频"]) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(sendVideoMsg:)]) {
            [self.delegate sendVideoMsg:@""];
        }
    }
}

#pragma mark - SET/GET

- (UIButton *)voice {
    
    if (_voice == nil) {
        _voice = [UIButton buttonWithType:UIButtonTypeCustom];
        _voice.frame = CGRectMake(LCChatSpaceH, LCChatSpaceV, LCChatBarBtn, LCChatBarBtn);
        [_voice setImage:[UIImage imageNamed:@"Chat_voice"] forState:UIControlStateNormal];
        [_voice setImage:[UIImage imageNamed:@"Chat_kb"] forState:UIControlStateSelected];
        [_voice setSelected:NO];
        [_voice addTarget:self action:@selector(buttonHandler:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_voice];
    }
    
    return _voice;
}

- (UIButton *)record {
    
    if (_record == nil) {
        _record = [UIButton buttonWithType:UIButtonTypeCustom];
        _record.width = self.width - 3 * LCChatBarBtn - 5 * LCChatSpaceH;
        _record.height = LCChatInput;
        _record.x = self.voice.right + LCChatSpaceH;
        _record.y = LCChatInputSpaceV;
        _record.layer.cornerRadius = 4.0;
        _record.layer.masksToBounds = YES;
        [_record setBackgroundColor:[UIColor whiteColor]];
        [_record setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_record.titleLabel setFont:[UIFont systemFontOfSize:15]];
        [_record setTitle:@"按住说话" forState:UIControlStateNormal];
        [_record setTitle:@"松开结束" forState:UIControlStateHighlighted];
        [_record addTarget:self action:@selector(startRecord:) forControlEvents:UIControlEventTouchDown];
        [_record addTarget:self action:@selector(endRecord:) forControlEvents:UIControlEventTouchUpInside];
        [_record addTarget:self action:@selector(cancelRecord:) forControlEvents:UIControlEventTouchUpOutside];
        [_record addTarget:self action:@selector(remindDragExit:) forControlEvents:UIControlEventTouchDragExit];
        [_record addTarget:self action:@selector(remindDragEnter:) forControlEvents:UIControlEventTouchDragEnter];
        [self addSubview:_record];
    }
    
    return _record;
}

- (UITextView *)input {
    
    if (_input == nil) {
        _input = [[UITextView alloc] initWithFrame:self.record.bounds];
        _input.backgroundColor = [UIColor whiteColor];
        _input.font = [UIFont systemFontOfSize:15];
        _input.textColor = [UIColor blackColor];
        _input.returnKeyType = UIReturnKeySend;
        _input.showsHorizontalScrollIndicator = NO;
        _input.showsVerticalScrollIndicator = NO;
        _input.enablesReturnKeyAutomatically = YES;
        _input.delegate = self;
        [self.record addSubview:_input];
    }
    
    return _input;
}

- (UIButton *)symbol {
    
    if (_symbol == nil) {
        _symbol = [UIButton buttonWithType:UIButtonTypeCustom];
        _symbol.frame = CGRectMake(self.record.right + LCChatSpaceH, LCChatSpaceV, LCChatBarBtn, LCChatBarBtn);
        [_symbol setImage:[UIImage imageNamed:@"Chat_symbol"] forState:UIControlStateNormal];
        [_symbol setImage:[UIImage imageNamed:@"Chat_kb"] forState:UIControlStateSelected];
        [_symbol setSelected:NO];
        [_symbol addTarget:self action:@selector(buttonHandler:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_symbol];
    }
    
    return _symbol;
}

- (UIButton *)add {
    
    if (_add == nil) {
        _add = [UIButton buttonWithType:UIButtonTypeCustom];
        _add.frame = CGRectMake(self.symbol.right + LCChatSpaceH, LCChatSpaceV, LCChatBarBtn, LCChatBarBtn);
        [_add setImage:[UIImage imageNamed:@"Chat_add"] forState:UIControlStateNormal];
        [_add setImage:[UIImage imageNamed:@"Chat_add"] forState:UIControlStateSelected];
        [_add setSelected:NO];
        [_add addTarget:self action:@selector(buttonHandler:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_add];
    }
    
    return _add;
}

@end
