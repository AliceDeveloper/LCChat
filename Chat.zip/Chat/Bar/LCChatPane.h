//
//  LCChatPane.h
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/9.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LCChatPaneType) {
    LCChatPaneType_Symbol,      // 表情
    LCChatPaneType_Add,         // 添加
};
#define LCChatPaneHeight    120 // 自定义面板高度

@protocol LCChatPaneDelegate <NSObject>

- (void)symbolItemClicked:(NSUInteger)index name:(NSString *)name;
- (void)addItemClicked:(NSUInteger)index name:(NSString *)name;

@end

@interface LCChatPane : UIView

@property (nonatomic, weak) id <LCChatPaneDelegate> delegate;
@property (nonatomic, assign) LCChatPaneType type;

@end

NS_ASSUME_NONNULL_END
