//
//  LCChatVideoCell.h
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/15.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface LCChatVideoCell : LCChatBaseCell

@property (nonatomic, strong) UIImageView *placeholderIv;
@property (nonatomic, strong) UIButton *playBtn;
@property (nonatomic, strong) UIImageView *timeBgIv;
@property (nonatomic, strong) UILabel *timeLenLabel;

@end

NS_ASSUME_NONNULL_END
