//
//  LCChatTextCell.h
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/15.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface LCChatTextCell : LCChatBaseCell

@property (nonatomic, strong) UIImageView *bgIv;
@property (nonatomic, strong) UILabel *textMsgLabel;

@end

NS_ASSUME_NONNULL_END
