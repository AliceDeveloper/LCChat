//
//  LCChatImageCell.m
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/9.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatImageCell.h"

@implementation LCChatImageCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        [self iv];
    }
    
    return self;
}

#pragma mark - SET/GET

- (void)setChatModel:(LCChatModel *)chatModel {
    [super setChatModel:chatModel];
    
    UIImage *image = [UIImage imageNamed:chatModel.imgUrl];
    self.iv.image = image;
    // 区分横图和竖图
    CGFloat maxWidth = image.size.width;
    CGFloat maxHeight = image.size.height;
    if (image.size.width >= image.size.height) {
        if (maxWidth > LCChatImageMaxW) {
            maxWidth = LCChatImageMaxW;
            maxHeight = image.size.height * maxWidth / image.size.width;
        }
    } else {
        if (maxHeight > LCChatImageMaxH) {
            maxHeight = LCChatImageMaxH;
            maxWidth = image.size.width * maxHeight / image.size.height;
        }
    }
    [self.iv mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.mas_lessThanOrEqualTo(maxWidth);
        make.height.mas_lessThanOrEqualTo(maxHeight);
    }];
    [self layoutIfNeeded];
}

- (UIImageView *)iv {
    
    if (_iv == nil) {
        _iv = [[UIImageView alloc] init];
        _iv.contentMode = UIViewContentModeScaleAspectFit;
        _iv.layer.cornerRadius = 4;
        _iv.layer.masksToBounds = YES;
        [self.bgBtn addSubview:_iv];
        [_iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.bottom.equalTo(self.bgBtn);
        }];
    }
    
    return _iv;
}

@end
