//
//  LCChatBaseCell.m
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/15.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatBaseCell.h"

@implementation LCChatBaseCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.layer.masksToBounds = YES;
        [self timeLabel];
        [self headBtn];
        [self bgBtn];
        [self statusBtn];
    }
    
    return self;
}

- (void)setChatModel:(LCChatModel *)chatModel {
    
    if (chatModel == nil) {
        return;
    }
    _chatModel = chatModel;
    
    // 时间
    _timeLabel.text = _chatModel.timeMsg;
    // 头像
    [_headBtn setImage:[UIImage imageNamed:_chatModel.headUrl] forState:UIControlStateNormal];
    // 消息状态
    switch (_chatModel.msgStatus) {
        case LCChatMsgStatus_Send:
            [self.statusBtn setImage:nil forState:UIControlStateNormal];
            break;
        case LCChatMsgStatus_Sending:
            [self.statusBtn setImage:[UIImage imageNamed:@"Chat_Sending"] forState:UIControlStateNormal];
            break;
        case LCChatMsgStatus_Unsend:
            [self.statusBtn setImage:[UIImage imageNamed:@"Chat_Resend"] forState:UIControlStateNormal];
            break;
        case LCChatMsgStatus_Read:
            [self.statusBtn setImage:nil forState:UIControlStateNormal];
            break;
        case LCChatMsgStatus_Unread:
            [self.statusBtn setImage:nil forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    
    // 判断是否是自己发送的消息
    if (_chatModel.isSelf) {
        [_headBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.width.height.mas_equalTo(LCChatHead);
            make.top.equalTo(self.timeLabel.mas_bottom).offset(LCChatCellSpace);
            make.bottom.mas_lessThanOrEqualTo(-LCChatCellSpace);
            make.right.mas_equalTo(-LCChatCellSpace);
        }];
        [_bgBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.width.height.mas_greaterThanOrEqualTo(LCChatHead);
            make.top.equalTo(self.headBtn.mas_top);
            make.bottom.mas_lessThanOrEqualTo(-LCChatCellSpace);
            make.left.mas_greaterThanOrEqualTo(LCChatCellSpace);
            make.right.equalTo(self.headBtn.mas_left).offset(-LCChatCellSpace);
        }];
        [_statusBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.width.height.mas_equalTo(LCChatStatusBtn);
            make.centerY.equalTo(self.bgBtn.mas_centerY);
            make.left.mas_greaterThanOrEqualTo(LCChatCellSpace);
            make.right.equalTo(self.bgBtn.mas_left).offset(-LCChatCellSpace);
        }];
    } else {
        [_headBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.width.height.mas_equalTo(LCChatHead);
            make.top.equalTo(self.timeLabel.mas_bottom).offset(LCChatCellSpace);
            make.bottom.mas_lessThanOrEqualTo(-LCChatCellSpace);
            make.left.mas_equalTo(LCChatCellSpace);
        }];
        [_bgBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.width.height.mas_greaterThanOrEqualTo(LCChatHead);
            make.top.equalTo(self.headBtn.mas_top);
            make.bottom.mas_lessThanOrEqualTo(-LCChatCellSpace);
            make.left.equalTo(self.headBtn.mas_right).offset(LCChatCellSpace);
            make.right.mas_lessThanOrEqualTo(-LCChatCellSpace);
        }];
        [_statusBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.width.height.mas_equalTo(LCChatStatusBtn);
            make.centerY.equalTo(self.bgBtn.mas_centerY);
            make.left.equalTo(self.bgBtn.mas_right).offset(LCChatCellSpace);
            make.right.mas_lessThanOrEqualTo(-LCChatCellSpace);
        }];
    }
}

// 聊天消息点击事件
- (void)chatCellBtnHandler:(UIButton *)sender {
}

#pragma mark - SET/GET

- (UILabel *)timeLabel {
    
    if (_timeLabel == nil) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.font = [UIFont systemFontOfSize:12];
        _timeLabel.textAlignment = NSTextAlignmentCenter;
        _timeLabel.textColor = [UIColor lightGrayColor];
        _timeLabel.backgroundColor = [UIColor whiteColor];
        [self addSubview:_timeLabel];
        [_timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(LCChatCellSpace);
            make.centerX.equalTo(self);
        }];
    }
    
    return _timeLabel;
}

- (UIButton *)headBtn {
    
    if (_headBtn == nil) {
        _headBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_headBtn addTarget:self action:@selector(chatCellBtnHandler:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_headBtn];
        [_headBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.height.mas_equalTo(LCChatHead);
        }];
    }
    
    return _headBtn;
}

- (UIButton *)bgBtn {
    
    if (_bgBtn == nil) {
        _bgBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_bgBtn addTarget:self action:@selector(chatCellBtnHandler:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_bgBtn];
        [_bgBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.headBtn.mas_top);
        }];
    }
    
    return _bgBtn;
}

- (UIButton *)statusBtn {
    
    if (_statusBtn == nil) {
        _statusBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_statusBtn addTarget:self action:@selector(chatCellBtnHandler:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_statusBtn];
        [_statusBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.bgBtn.mas_centerY);
            make.width.height.mas_equalTo(LCChatStatusBtn);
        }];
    }
    
    return _statusBtn;
}

#pragma mark - 工具

// 聊天气泡
- (UIImage *)imageResizable:(NSString *)name {
    
    // 因为背景图片高度是44
    UIImage *normal = [UIImage imageNamed:name];
    UIImage *resizable = [normal resizableImageWithCapInsets:UIEdgeInsetsMake(33, 20, 11, 20)];
    
    return resizable;
}

@end
