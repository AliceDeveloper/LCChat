//
//  LCChatVoiceCell.m
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/15.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatVoiceCell.h"

@implementation LCChatVoiceCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        [self animationIv];
        [self timeLenLabel];
    }
    
    return self;
}

#pragma mark - SET/GET

- (void)setChatModel:(LCChatModel *)chatModel {
    [super setChatModel:chatModel];
    
    self.timeLenLabel.text = [chatModel.voiceLen stringByAppendingString:@"''"];
    CGFloat length = chatModel.voiceLen.floatValue * (LCChatVoiceMaxL - LCChatVoiceMinL) / (LCChatVoiceMaxT - LCChatVoiceMinT) + LCChatVoiceMinL;
    [self.bgBtn mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(length);
    }];
    if (chatModel.isSelf) {
        [self.bgBtn setBackgroundImage:[self imageResizable:@"Chat_selfBg"] forState:UIControlStateNormal];
        [self.animationIv setImage:[UIImage imageNamed:@"Chat_voice_self"]];
        [self.animationIv mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.bgBtn);
            make.width.height.mas_equalTo(LCChatStatusBtn);
            make.right.mas_equalTo(-LCChatCellSpace);
        }];
        [self.timeLenLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.bgBtn);
            make.right.equalTo(self.animationIv.mas_left).offset(-LCChatCellSpace);
        }];
    } else {
        [self.bgBtn setBackgroundImage:[self imageResizable:@"Chat_otherBg"] forState:UIControlStateNormal];
        [self.animationIv setImage:[UIImage imageNamed:@"Chat_voice_other"]];
        [self.animationIv mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.bgBtn);
            make.width.height.mas_equalTo(LCChatStatusBtn);
            make.left.mas_equalTo(LCChatCellSpace);
        }];
        [self.timeLenLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.bgBtn);
            make.left.equalTo(self.animationIv.mas_right).offset(LCChatCellSpace);
        }];
    }
    [self layoutIfNeeded];
}

- (UIImageView *)animationIv {
    
    if (_animationIv == nil) {
        _animationIv = [[UIImageView alloc] init];
        [self.bgBtn addSubview:_animationIv];
        [_animationIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.height.mas_equalTo(LCChatStatusBtn);
            make.centerY.equalTo(self.bgBtn);
        }];
    }
    
    return _animationIv;
}

- (UILabel *)timeLenLabel {
    
    if (_timeLenLabel == nil) {
        _timeLenLabel = [[UILabel alloc] init];
        _timeLenLabel.font = [UIFont systemFontOfSize:15];
        _timeLenLabel.textColor = [UIColor blackColor];
        [self.bgBtn addSubview:_timeLenLabel];
        [_timeLenLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.bgBtn);
        }];
    }
    
    return _timeLenLabel;
}

@end
