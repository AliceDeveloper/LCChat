//
//  LCChatBaseCell.h
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/15.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LCChatModel.h"

NS_ASSUME_NONNULL_BEGIN

#define LCChatCellSpace         8   // cell视图的间隙
#define LCChatHead              40  // 头像宽高
#define LCChatStatusBtn         20  // 消息状态宽高

#define LCChatImageMaxW         ([UIScreen mainScreen].bounds.size.width / 2) // 图片的最大宽度
#define LCChatImageMaxH         ([UIScreen mainScreen].bounds.size.width / 2) // 图片的最大高度

#define LCChatVoiceMaxL         ([UIScreen mainScreen].bounds.size.width / 2) // 语音的最大宽度
#define LCChatVoiceMinL         80  // 语音的最小宽度
#define LCChatVoiceMaxT         30  // 最大时长
#define LCChatVoiceMinT         1   // 最小时长

#define LCChatVideoBtn          40  // 视频播放按钮的宽高
#define LCChatVideoTimeH        20  // 视频时长高度

@protocol LCChatBaseCellDelegate <NSObject>

@end

@interface LCChatBaseCell : UITableViewCell

@property (nonatomic, weak) id <LCChatBaseCellDelegate> delegate;
@property (nonatomic, strong) NSIndexPath *indexPath;
@property (nonatomic, strong) LCChatModel *chatModel;
// 时间、头像、背景图、发送状态或消息状态
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UIButton *headBtn;
@property (nonatomic, strong) UIButton *bgBtn;
@property (nonatomic, strong) UIButton *statusBtn;
// 聊天消息点击事件
- (void)chatCellBtnHandler:(UIButton *)sender;

#pragma mark - 工具

// 聊天气泡
- (UIImage *)imageResizable:(NSString *)name;

@end

NS_ASSUME_NONNULL_END
