//
//  LCChatVideoCell.m
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/15.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatVideoCell.h"

@implementation LCChatVideoCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        [self placeholderIv];
        [self playBtn];
        [self timeBgIv];
        [self timeLenLabel];
    }
    
    return self;
}

#pragma mark - SET/GET

- (void)setChatModel:(LCChatModel *)chatModel {
    [super setChatModel:chatModel];
    
    UIImage *image = [UIImage imageNamed:chatModel.videoPlaceUrl];
    [self.placeholderIv setImage:image];
    [self.timeLenLabel setText:chatModel.videoLen];
    
    // 区分视频占位图是横图和竖图
    CGFloat maxWidth = image.size.width;
    CGFloat maxHeight = image.size.height;
    if (image.size.width >= image.size.height) {
        if (maxWidth > LCChatImageMaxW) {
            maxWidth = LCChatImageMaxW;
            maxHeight = image.size.height * maxWidth / image.size.width;
        }
    } else {
        if (maxHeight > LCChatImageMaxH) {
            maxHeight = LCChatImageMaxH;
            maxWidth = image.size.width * maxHeight / image.size.height;
        }
    }
    [self.placeholderIv mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.mas_lessThanOrEqualTo(maxWidth);
        make.height.mas_lessThanOrEqualTo(maxHeight);
    }];
    [self layoutIfNeeded];
}

- (UIImageView *)placeholderIv {
    
    if (_placeholderIv == nil) {
        _placeholderIv = [[UIImageView alloc] init];
        _placeholderIv.contentMode = UIViewContentModeScaleAspectFit;
        _placeholderIv.layer.cornerRadius = 4;
        _placeholderIv.layer.masksToBounds = YES;
        [self.bgBtn addSubview:_placeholderIv];
        [_placeholderIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.bottom.equalTo(self.bgBtn);
        }];
    }
    
    return _placeholderIv;
}

- (UIButton *)playBtn {
    
    if (_playBtn == nil) {
        _playBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_playBtn setImage:[UIImage imageNamed:@"Chat_play"] forState:UIControlStateNormal];
        [_playBtn addTarget:self action:@selector(chatCellBtnHandler:) forControlEvents:UIControlEventTouchUpInside];
        [self.bgBtn addSubview:_playBtn];
        [_playBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.height.mas_equalTo(LCChatVideoBtn);
            make.center.equalTo(self.bgBtn);
        }];
    }
    
    return _playBtn;
}

- (UIImageView *)timeBgIv {
    
    if (_timeBgIv == nil) {
        _timeBgIv = [[UIImageView alloc] init];
        [_timeBgIv setBackgroundColor:[[UIColor blackColor] colorWithAlphaComponent:0.2]];
        [self.placeholderIv addSubview:_timeBgIv];
        [_timeBgIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(LCChatVideoTimeH);
            make.left.right.bottom.equalTo(self.placeholderIv);
        }];
    }
    
    return _timeBgIv;
}

- (UILabel *)timeLenLabel {
    
    if (_timeLenLabel == nil) {
        _timeLenLabel = [[UILabel alloc] init];
        _timeLenLabel.font = [UIFont systemFontOfSize:13];
        _timeLenLabel.textColor = [UIColor whiteColor];
        _timeLenLabel.textAlignment = NSTextAlignmentRight;
        [self.timeBgIv addSubview:_timeLenLabel];
        [_timeLenLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(LCChatVideoTimeH);
            make.left.mas_greaterThanOrEqualTo(LCChatCellSpace);
            make.right.equalTo(self.timeBgIv).offset(-LCChatCellSpace);
        }];
    }
    
    return _timeLenLabel;
}

@end
