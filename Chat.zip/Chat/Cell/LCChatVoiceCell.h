//
//  LCChatVoiceCell.h
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/15.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface LCChatVoiceCell : LCChatBaseCell

@property (nonatomic, strong) UIImageView *animationIv;
@property (nonatomic, strong) UILabel *timeLenLabel;

@end

NS_ASSUME_NONNULL_END
