//
//  LCChatTextCell.m
//  LCRACMVVMRouter
//
//  Created by 李春 on 2019/1/15.
//  Copyright © 2019 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatTextCell.h"

@implementation LCChatTextCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        [self bgIv];
        [self textMsgLabel];
    }
    
    return self;
}

#pragma mark - SET/GET

- (void)setChatModel:(LCChatModel *)chatModel {
    [super setChatModel:chatModel];
    
    _textMsgLabel.text = chatModel.textMsg;
    if (chatModel.isSelf) {
        [self.bgIv setImage:[self imageResizable:@"Chat_selfBg"]];
    } else {
        [self.bgIv setImage:[self imageResizable:@"Chat_otherBg"]];
    }
    [self layoutIfNeeded];
}

- (UIImageView *)bgIv {
    
    if (_bgIv == nil) {
        _bgIv = [[UIImageView alloc] init];
        [self.bgBtn addSubview:_bgIv];
        [_bgIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.bottom.equalTo(self.bgBtn);
        }];
    }
    
    return _bgIv;
}

- (UILabel *)textMsgLabel {
    
    if (_textMsgLabel == nil) {
        _textMsgLabel = [[UILabel alloc] init];
        _textMsgLabel.numberOfLines = 0;
        _textMsgLabel.lineBreakMode = NSLineBreakByCharWrapping;
        _textMsgLabel.font = [UIFont systemFontOfSize:15];
        _textMsgLabel.textColor = [UIColor blackColor];
        [self.bgBtn addSubview:_textMsgLabel];
        [_textMsgLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(LCChatCellSpace * 2);
            make.right.mas_equalTo(-LCChatCellSpace * 2);
            make.top.mas_equalTo(LCChatCellSpace);
            make.bottom.mas_equalTo(-LCChatCellSpace);
        }];
    }
    
    return _textMsgLabel;
}

@end
