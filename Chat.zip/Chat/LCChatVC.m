//
//  LCChatVC.m
//  LCRACMVVMRouter
//
//  Created by 李春 on 2018/12/24.
//  Copyright © 2018 LCRACMVVMRouter. All rights reserved.
//

#import "LCChatVC.h"
#import "UIView+Chat.h"
#import "LCChatBar.h"
#import "LCChatTextCell.h"
#import "LCChatImageCell.h"
#import "LCChatVoiceCell.h"
#import "LCChatVideoCell.h"

@interface LCChatVC ()
<UITableViewDelegate,
UITableViewDataSource,
LCChatBarDelegate,
LCChatBaseCellDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) LCChatBar *bar;
@property (nonatomic, strong) NSMutableArray *dataSource;

@end

@implementation LCChatVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"Friend";
    [self tableView];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [IQKeyboardManager sharedManager].enable = NO;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [IQKeyboardManager sharedManager].enable = YES;
}

#pragma mark - <UITableViewDelegate, UITableViewDataSource>

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    LCChatBaseCell *cell = nil;
    LCChatModel *model = self.dataSource[indexPath.row];
    if (model.msgType == LCChatMsgType_Text) {
        cell = (LCChatTextCell *)[tableView dequeueReusableCellWithIdentifier:@"LCChatTextCell" forIndexPath:indexPath];
    }
    if (model.msgType == LCChatMsgType_Image) {
        cell = (LCChatImageCell *)[tableView dequeueReusableCellWithIdentifier:@"LCChatImageCell" forIndexPath:indexPath];
    }
    if (model.msgType == LCChatMsgType_Voice) {
        cell = (LCChatVoiceCell *)[tableView dequeueReusableCellWithIdentifier:@"LCChatVoiceCell" forIndexPath:indexPath];
    }
    if (model.msgType == LCChatMsgType_Video) {
        cell = (LCChatVideoCell *)[tableView dequeueReusableCellWithIdentifier:@"LCChatVideoCell" forIndexPath:indexPath];
    }
    cell.delegate = self;
    cell.indexPath = indexPath;
    cell.chatModel = model;
    
    return cell;
}

#pragma mark - <LCChatBaseCellDelegate>

#pragma mark - <LCChatBarDelegate>

- (void)refreshUI {
    
    [self.tableView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.bar.mas_top);
    }];
    [self scrollsToBottom];
}

- (void)sendTextMsg:(NSString *)msg {
    
    [self.dataSource addObjectsFromArray:[LCChatModel textDemo]];
    [self.tableView reloadData];
    [self scrollsToBottom];
}

- (void)sendImageMsg:(UIImage *)img {
    
    [self.dataSource addObjectsFromArray:[LCChatModel imgDemo]];
    [self.tableView reloadData];
    [self scrollsToBottom];
}

- (void)sendVideoMsg:(NSString *)videoPath {
    
    [self.dataSource addObjectsFromArray:[LCChatModel videoDemo]];
    [self.tableView reloadData];
    [self scrollsToBottom];
}

- (void)sendVoiceMsg:(NSString *)voicePath {
    
    [self.dataSource addObjectsFromArray:[LCChatModel voiceDemo]];
    [self.tableView reloadData];
    [self scrollsToBottom];
}

#pragma mark -

- (void)scrollsToBottom {
    
    if (self.dataSource.count > 0) {
        [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataSource.count - 1 inSection:0]
                              atScrollPosition:UITableViewScrollPositionNone
                                      animated:YES];
    }
}

#pragma mark - SET/GET

- (UITableView *)tableView {
    
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.estimatedRowHeight = 100;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        _tableView.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.equalTo(self.view);
            make.bottom.equalTo(self.bar.mas_top);
        }];
        [_tableView registerClass:[LCChatTextCell class]
           forCellReuseIdentifier:@"LCChatTextCell"];
        [_tableView registerClass:[LCChatImageCell class]
           forCellReuseIdentifier:@"LCChatImageCell"];
        [_tableView registerClass:[LCChatVoiceCell class]
           forCellReuseIdentifier:@"LCChatVoiceCell"];
        [_tableView registerClass:[LCChatVideoCell class]
           forCellReuseIdentifier:@"LCChatVideoCell"];
    }
    
    return _tableView;
}

- (LCChatBar *)bar {
    
    if (_bar == nil) {
        _bar = [[LCChatBar alloc] initWithOwner:self];
        _bar.delegate = self;
        [self.view addSubview:_bar];
        LCChatPane *pane = [[LCChatPane alloc] init];
        pane.frame = CGRectMake(_bar.left, _bar.bottom, _bar.width, LCChatPaneHeight);
        pane.delegate = _bar;
        [self.view addSubview:pane];
        _bar.pane = pane;
    }
    
    return _bar;
}

- (NSMutableArray *)dataSource {
    
    if (_dataSource == nil) {
        _dataSource = [NSMutableArray array];
    }
    
    return _dataSource;
}

@end
